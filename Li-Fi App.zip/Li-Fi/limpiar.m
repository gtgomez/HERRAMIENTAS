function limpiar()
   hold off;
   plot(0,0,'k');
   grid on;
   set(gca,'XLim',[0 1],'YLim',[0 1]);
end